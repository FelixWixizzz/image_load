login = "Youserenity"
password = "Cerf,kznm432!"

size = "Size: 400 pixels wide"
watermark = True

description = "Описание"
tags = "Теги"

tools = "no"
datasets = "no"

mature_content = ['Nudity', ]

scraps = True
gallery = ["test"]

points = 200

